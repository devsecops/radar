# -*- coding: utf-8 -*-

from securitychecker import main
main()
